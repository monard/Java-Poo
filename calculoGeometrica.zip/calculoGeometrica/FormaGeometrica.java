package Geometrica;

public class FormaGeometrica {
    String cor;

    public FormaGeometrica(String cor) {
        this.cor = cor;
    }

    public double calculaPerimetro(){
        System.out.println("Não implementado!");
        return 0.0;
    }

    public double calculaArea() {
        System.out.println("Não implementado!");
        return 0.0;
    }

    public double calculaVolume(){
        System.out.println("Não implementado");
        return 0.0;
    }
}